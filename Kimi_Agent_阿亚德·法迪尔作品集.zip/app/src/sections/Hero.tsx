import { useEffect, useRef } from 'react'
import gsap from 'gsap'

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null)
  const labelRef = useRef<HTMLParagraphElement>(null)
  const headingRef = useRef<HTMLHeadingElement>(null)
  const subtitleRef = useRef<HTMLParagraphElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ delay: 0.3 })
      tl.to(labelRef.current, { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' })
        .to(headingRef.current, { opacity: 1, y: 0, duration: 0.7, ease: 'power2.out' }, '-=0.3')
        .to(subtitleRef.current, { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' }, '-=0.3')
        .to(ctaRef.current, { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out' }, '-=0.2')
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      style={{
        height: '100vh',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'flex-end',
      }}
    >
      {/* Content */}
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          maxWidth: '1200px',
          margin: '0 auto',
          width: '100%',
          padding: '0 24px',
          paddingBottom: '15vh',
        }}
      >
        <p
          ref={labelRef}
          className="font-body"
          style={{
            opacity: 0,
            transform: 'translateY(20px)',
            fontWeight: 500,
            fontSize: '0.75rem',
            letterSpacing: '0.12em',
            textTransform: 'uppercase',
            color: '#5A6B68',
            marginBottom: '16px',
          }}
        >
          PROFESSOR OF APPLIED REMOTE SENSING & GIS
        </p>

        <h1
          ref={headingRef}
          className="font-display"
          style={{
            opacity: 0,
            transform: 'translateY(30px)',
            fontWeight: 600,
            fontSize: 'clamp(2.5rem, 5.5vw, 4.5rem)',
            lineHeight: 1.05,
            letterSpacing: '-0.02em',
            color: '#1E2D2B',
            maxWidth: '600px',
          }}
        >
          Mapping Earth's Systems
        </h1>

        <p
          ref={subtitleRef}
          className="font-body"
          style={{
            opacity: 0,
            transform: 'translateY(20px)',
            fontWeight: 400,
            fontSize: '1.125rem',
            lineHeight: 1.6,
            color: '#5A6B68',
            maxWidth: '520px',
            marginTop: '20px',
          }}
        >
          Four decades of research in remote sensing, GIS, and environmental monitoring across the Middle East, Asia, Africa, and beyond.
        </p>

        <div
          ref={ctaRef}
          style={{
            opacity: 0,
            transform: 'translateY(20px)',
            marginTop: '32px',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '16px',
          }}
        >
          <a
            href="#publications"
            onClick={(e) => {
              e.preventDefault()
              document.querySelector('#publications')?.scrollIntoView({ behavior: 'smooth' })
            }}
            className="font-display"
            style={{
              display: 'inline-block',
              background: 'linear-gradient(135deg, #C8963E 0%, #A67B2D 100%)',
              color: '#FFFFFF',
              fontWeight: 600,
              fontSize: '1rem',
              padding: '14px 28px',
              borderRadius: '12px',
              textDecoration: 'none',
              boxShadow: '0 4px 16px rgba(200, 150, 62, 0.3)',
              transition: 'all 0.25s ease',
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget
              el.style.transform = 'translateY(-2px)'
              el.style.boxShadow = '0 6px 24px rgba(200, 150, 62, 0.4)'
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget
              el.style.transform = 'translateY(0)'
              el.style.boxShadow = '0 4px 16px rgba(200, 150, 62, 0.3)'
            }}
          >
            View Publications
          </a>

          <a
            href="https://www.researchgate.net/profile/Ayad-Al-Quraishi"
            target="_blank"
            rel="noopener noreferrer"
            className="font-display"
            style={{
              display: 'inline-block',
              background: 'transparent',
              color: '#1B4D48',
              fontWeight: 500,
              fontSize: '1rem',
              padding: '14px 24px',
              borderRadius: '12px',
              textDecoration: 'none',
              border: '1px solid rgba(37, 109, 102, 0.25)',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(37, 109, 102, 0.06)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent'
            }}
          >
            ResearchGate →
          </a>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          width: '100%',
          height: '25vh',
          background:
            'linear-gradient(180deg, transparent 0%, rgba(248,245,240,0.85) 70%, rgba(248,245,240,1.0) 100%)',
          zIndex: 5,
          pointerEvents: 'none',
        }}
      />
    </section>
  )
}
