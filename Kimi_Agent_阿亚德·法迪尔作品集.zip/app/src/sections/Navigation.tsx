import { useState, useEffect } from 'react'

const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Publications', href: '#publications' },
  { label: 'Books', href: '#books' },
  { label: 'Courses', href: '#courses' },
  { label: 'Research', href: '#research' },
  { label: 'Contact', href: '#contact' },
]

export default function Navigation() {
  const [activeSection, setActiveSection] = useState('')
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const sections = navLinks.map((l) => l.href.replace('#', ''))
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id)
          }
        })
      },
      { threshold: 0.3 }
    )

    sections.forEach((id) => {
      const el = document.getElementById(id)
      if (el) observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    const target = document.querySelector(href)
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' })
    }
    setMobileOpen(false)
  }

  return (
    <>
      <nav
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 100,
          background: 'rgba(255, 255, 255, 0.92)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          borderBottom: '1px solid rgba(37, 109, 102, 0.08)',
          height: '64px',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '0 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            height: '100%',
          }}
        >
          {/* Logo */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              window.scrollTo({ top: 0, behavior: 'smooth' })
            }}
            className="font-display"
            style={{
              fontWeight: 600,
              fontSize: '1rem',
              color: '#1B4D48',
              textDecoration: 'none',
              whiteSpace: 'nowrap',
            }}
          >
            <span className="hidden md:inline">Prof. Dr. Ayad M. Fadhil Al-Quraishi</span>
            <span className="md:hidden">Prof. Al-Quraishi</span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex" style={{ gap: '28px', alignItems: 'center' }}>
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleClick(e, link.href)}
                className="font-display"
                style={{
                  fontWeight: 500,
                  fontSize: '0.875rem',
                  color: activeSection === link.href.replace('#', '') ? '#1B4D48' : '#5A6B68',
                  textDecoration: 'none',
                  position: 'relative',
                  paddingBottom: '4px',
                  transition: 'color 0.25s ease',
                }}
                onMouseEnter={(e) => {
                  ;(e.target as HTMLElement).style.color = '#256D66'
                }}
                onMouseLeave={(e) => {
                  const isActive = activeSection === link.href.replace('#', '')
                  ;(e.target as HTMLElement).style.color = isActive ? '#1B4D48' : '#5A6B68'
                }}
              >
                {link.label}
                <span
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    width: activeSection === link.href.replace('#', '') ? '100%' : '0%',
                    height: '2px',
                    background: '#1B4D48',
                    transition: 'width 0.25s ease',
                  }}
                />
              </a>
            ))}
          </div>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '8px',
              display: 'flex',
              flexDirection: 'column',
              gap: '5px',
            }}
          >
            <span
              style={{
                width: '24px',
                height: '2px',
                background: '#1B4D48',
                transition: 'all 0.3s ease',
                transform: mobileOpen ? 'rotate(45deg) translate(5px, 5px)' : 'none',
              }}
            />
            <span
              style={{
                width: '24px',
                height: '2px',
                background: '#1B4D48',
                transition: 'all 0.3s ease',
                opacity: mobileOpen ? 0 : 1,
              }}
            />
            <span
              style={{
                width: '24px',
                height: '2px',
                background: '#1B4D48',
                transition: 'all 0.3s ease',
                transform: mobileOpen ? 'rotate(-45deg) translate(5px, -5px)' : 'none',
              }}
            />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {mobileOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 99,
            background: 'rgba(30, 45, 43, 0.5)',
          }}
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Menu Panel */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          right: 0,
          width: '280px',
          height: '100vh',
          background: '#FFFFFF',
          zIndex: 101,
          transform: mobileOpen ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.3s ease',
          padding: '80px 32px 32px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
        }}
      >
        {navLinks.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => handleClick(e, link.href)}
            className="font-display"
            style={{
              fontWeight: 500,
              fontSize: '1.25rem',
              color: activeSection === link.href.replace('#', '') ? '#256D66' : '#1E2D2B',
              textDecoration: 'none',
              padding: '12px 0',
              transition: 'all 0.2s ease',
              borderBottom: '1px solid rgba(37, 109, 102, 0.08)',
            }}
          >
            {link.label}
          </a>
        ))}
      </div>
    </>
  )
}
